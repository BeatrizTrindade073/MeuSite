﻿<html>

<head>
	<title>Beatriz Trindade</title>
 	<meta http-equiv= "Content-Type" content= "text/html; charset=iso-8859-1">
   	<meta name="viewport" content="width=device-width, initial-scale=1.0">
   	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="homestyle.css"/>

</head>

<body>

	<?php
		include_once("header.php"); 
		include_once("footer.php");

	?>
	
	<div class="container">
	
		<div class="img-pg">
			
			<img id="foto" src='img/bia.jpeg' height = '265px' width='150px'/>

			<p id="paragrafo">
		Meu nome é Beatriz, tenho 17 anos e moro em Cataguases, Minas Gerais. Concluí o Ensino Médio Integrado ao Técnico em Informática no Centro Federal de Educação Tecnológica de Minas Gerais - Campus Leopoldina no ano de 2022. Foi lá que entre todas as áreas, eu me apaixonei por Desenvolvimento Web e tive a oportunidade de desenvolver o Front-End do Projeto Interdisciplinar do qual fiz parte, o CarbsCounter.
			</p>
		
		</div>

</br>

		<p id="p1">
			Sou fluente em Inglês, tendo cursado o idioma até o nível Pré-Avançado no Sheffield Idiomas, totalizando cerca de 10 anos de estudo. Também tive chance de atuar como monitora na área na mesma escola por aproximadamente 2 anos.
		</p>

</br>

		<p id="p1">
		Procuro melhorar minhas habilidades, além de desenvolver novas, focando em dar o meu melhor em tudo que me candidato a realizar.
		</p>

</br>	

	</div>

</br>
</br>
</br>
</br>

</body>
</html>
﻿<html>

<head>

	<title>Beatriz Trindade</title>
	<meta http-equiv= "Content-Type" content= "text/html; charset=iso-8859-1">		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
	<link rel="stylesheet" type="text/css" href="homestyle.css"/>
	
</head>

<body>

	<?php
		include_once("header.php"); 
		include_once("footer.php");

	?>


</br>
</br>

	<div class="container">
		<p id="p1">

<h1> Cursos Realizados </h1>
</br>
			
		 Curso Técnico em Informática, Centro Federal de Educação Tecnológica de Minas Gerais (CEFET-MG Campus III) 

</br>
</br>
</br>
 Curso de Excel 2016, Básico, Fundação Bradesco 
<a href="https://drive.google.com/file/d/1JzXS9Ka8OX3_MBGWqOMfAne2lV54B1_D/view?usp=sharing"></br> Visualizar Certificação </br> </a>

</br>
</br>
</br>

Curso sobre a Lei Geral de Proteção de Dados (LGPD), Fundação Bradesco 
<a href="https://drive.google.com/file/d/1tSLN49o85asDsGbxPtLNUw4Auc8Yo_9J/view?usp=sharing"> </br> Visualizar Certificação </br> </a>



</br>
</br>
</br>

Curso de SharePoint, Fundação Bradesco 
<a href="https://drive.google.com/file/d/1ISQm0pfqHWk7zLMDuF77VEdTqpFByCdS/view?usp=sharing"> </br> Visualizar Certificação </br> </a>

</br>
</br>
</br>

Curso de Fundamentos de TI: Hardware e Software, Fundação Bradesco 
<a href="https://drive.google.com/file/d/1S0DHufnnIu9LjUj_GteubOjAwfT7fEZG/view?usp=sharing"> </br> Visualizar Certificação </br> </a>

</br>
</br>
</br>

Curso de Phonegap e Apache Cordova, Portal Loiane Training 
<a href="https://loiane.training/certificado/xRsKzQk7B910U9BiVZrT"> </br> Visualizar Certificação </br> </a>

</br>
</br>
</br>

Curso de Inglês, Básico ao Avançado, Sheffield Idiomas 
<a href="https://drive.google.com/file/d/1j2vaI_kxdbCtOKRE3i4C82b6ErUDdnKT/view?usp=drivesdk"> </br> Visualizar Certificação </br> </a>

		</p>
	</div>

</br>
</br>
</br>
</br>

</body>



</html>
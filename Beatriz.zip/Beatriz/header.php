﻿<header>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12 navbar">
			<img id="logo" src='img/bt3.png' height = '155px' width='160px' class="logo navbar-brand text-white offset-md-2"/>
		
			<ul class="nav">
				<li class="nav-item"> <a href="home.php" class="nav-link"> Sobre mim </a> </li>
				<li class="nav-item"> <a href="cursos.php" class="nav-link"> Qualificações </a> </li>
				</ul>
			</div>		
		</div>
	</div>
</div>


</header>
﻿<footer class="rodape">
        <ul class="icones">
            <li><a href="https://www.linkedin.com/in/beatriz-trindade-4956301a3/"><img src="img/linkedin.png" height = '20px' width='20px' alt="Icone do Linkedin"></a></li>
            <li><a href="mailto:beatriz.trindade.work@gmail.com?"><img src="img/gmail.png" height = '20px' width='20px' alt="Icone do Gmail"></a></li>
            <li><a href="https://github.com/BeatrizTrindade073/Carbsofc.git" target="_blank"><img src="img/github.png" height = '20px' width='20px' alt="Icone do GitHub"></a></li>
        </ul>
         Beatriz Trindade da Silva 
 

        </footer>
